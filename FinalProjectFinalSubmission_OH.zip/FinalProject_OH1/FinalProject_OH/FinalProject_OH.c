// --------------------------------------------------------------------------------
// Name: Oliver Hand
// Class: SET-151-400
// Abstract: Final Project - Survey Application
// --------------------------------------------------------------------------------

// --------------------------------------------------------------------------------
// Includes � built-in libraries of functions
// --------------------------------------------------------------------------------
#define _CRT_SECURE_NO_WARNINGS // This was added because otherwise, I could not use scanf

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include<string.h> //Included to enable srtof functionality
// --------------------------------------------------------------------------------
// Constants
// --------------------------------------------------------------------------------
#define true 1;
#define false 0;

// --------------------------------------------------------------------------------
// User Defined Types (UDT)
// --------------------------------------------------------------------------------
typedef int boolean;

typedef struct
{
	char strDate[50];
	char strState[50];
	char strCounty[50];
	char strRace[50];
	short shtNumberInHouse;
	float sngYearlyIncome;
} udtSurveyType;
// --------------------------------------------------------------------------------
// Prototypes
// --------------------------------------------------------------------------------
void AskForNextAction(int* pintNextAction);
void CollectData();
void GetSurveyDate(char strSurveyData[]);
int GetState(char strSurveyData[]);
void GetCounty(int intState, char strSurveyData[]);
void GetOhioCounty(char strSurveyData[]);
void GetKentuckyCounty(char strSurveyData[]);
void GetRace(char strSurveyData[]);
void GetNumberInHousehold(char strSurveyData[]);
void GetYearlyIncome(char strSurveyData[]);
int AskForMoreData();
void DisplayData();
int AskForNextDisplay();
void GetTotalSurveys(udtSurveyType* paudtSurveyDataList, int intArraySize);
void GetTotalSurveysByCounty(udtSurveyType* paudtSurveyDataList, int intArraySize);
void GetTotalSurveysByRace(udtSurveyType* paudtSurveyDataList, int intArraySize);
void GetAverageIncome(udtSurveyType* paudtSurveyDataList, int intArraySize);
void GetAverageIncomeByCounty(udtSurveyType* paudtSurveyDataList, int intArraySize);
void GetAverageIncomeByRace(udtSurveyType* paudtSurveyDataList, int intArraySize);
void GetPovertyRate(udtSurveyType* paudtSurveyDataList, int intArraySize);
void GetPovertyRateByCounty(udtSurveyType* paudtSurveyDataList, int intArraySize);
void GetPovertyRateByRace(udtSurveyType* paudtSurveyDataList, int intArraySize);
void FindPovertyBracket(int intIndex, udtSurveyType* paudtSurveyDataList, float* psngTotalSurveys, float* psngTotalPoverty);
float CheckPovertyRate(float sngYearlyIncome, float sngPovertyThreshold);

//File Subroutines and Functions
int OpenInputFileForAppending(char strFileName[], FILE** ppfilInput);
int OpenInputFileForReading(char strFileName[], FILE** ppfilInput);
int FindSizeOfFile();
void ProcessData(udtSurveyType* paudtSurveyDataList, int intArraySize);
void InsertData(int intIndex, char strBuffer[], udtSurveyType* paudtSurveyDataList);
void BreakDownSurveyData(int* pintCommaCount, udtSurveyType* pudtSurveyData,
	char strPlaceHolder[]);

//Array Subroutines and Functions
void InitializeArray(char strSource[], int intArraySize);
void InitializeSurveyList(udtSurveyType* paudtSurveyDataList, int intArraySize);
void InitializeSurvey(udtSurveyType* ppudtSurveyData);

//String Subroutines and Functions
void AppendStrSurveyData(char strSource[], char strDestination[]);
void CopyStringArray(char strSource[], char strDestination[], int intStartPoint, int intStopPoint);
void CopyString(char strDestination[], char strSource[]);
void ClearString(char strSource[]);
void AppendStringWithCharacter(char strDestination[], char strSource);
int CheckForContent(udtSurveyType* pudtSurveyData, int intTotal);
short ConvertStringToShort(char strSource[]);
int FindLengthOfString(char strSource[]);
int ReadState(char strState[]);
int ReadOhioCounty(char strCounty[]);
int ReadKentuckyCounty(char strCounty[]);
int ReadRace(char strRace[]);

// --------------------------------------------------------------------------------
// Name: main
// Abstract: This is where the program starts
// --------------------------------------------------------------------------------
int main()
{
	//Declaring Variables
	int intNextAction = 0;
	int* pintNextAction = &intNextAction;

	do
	{
		AskForNextAction(pintNextAction);
		switch (intNextAction)
		{
		case 1:
			CollectData();
			break;
		case 2:
			DisplayData();
			break;
		default:
			break;
		}
	} while (intNextAction != 0);


	return 0;
}



// --------------------------------------------------------------------------------
// Name: AskForNextAction
// Abstract: Asks what the user wants to do
// --------------------------------------------------------------------------------
void AskForNextAction(int* pintNextAction)
{
	do
	{
		printf("----------------------------------------------------------------------------- \n");
		printf("What would you like to do? \n");
		printf("(1 = Write Mode, 2 = Display Mode, 0 = Exit Program) \n");
		printf("----------------------------------------------------------------------------- \n");
		scanf("%d", pintNextAction);
	} while (*pintNextAction < 0 || *pintNextAction > 2);
}


// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------
// Mode 1: Collect Data
// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------



// --------------------------------------------------------------------------------
// Name: CollectData
// Abstract: Gets, Validates, and Stores user input in SurveyData.txt 
// --------------------------------------------------------------------------------
void CollectData()
{
	//Declaring Variables
	int intAgain = 0;
	char strSurveyData[200] = "";
	int intState = 0;
	FILE* pfilInput = 0;
	int intResultFlag = 0;

	do
	{
		//Collecting User Input
		GetSurveyDate(strSurveyData);
		intState = GetState(strSurveyData); // Returns intState for use in GetCounty
		GetCounty(intState, strSurveyData);
		GetRace(strSurveyData);
		GetNumberInHousehold(strSurveyData);
		GetYearlyIncome(strSurveyData);

		// Try to open the file for reading (notice you have to double up the backslashes)
		intResultFlag = OpenInputFileForAppending("SurveyData.txt", &pfilInput);

		// Was the file opened?
		if (intResultFlag == 1)
		{
			// Yes, inserts strSurveyData
			fprintf(pfilInput, "%s", strSurveyData);

			// Clean up
			fclose(pfilInput);
		}
		//Resets strSurveyData for future use
		ClearString(strSurveyData);

		//Asks if there is another survey to be entered
		intAgain = AskForMoreData();
	} while (intAgain != 0);
}



// --------------------------------------------------------------------------------
// Name: GetSurveyDate
// Abstract: Gets the date this survey was taken
// --------------------------------------------------------------------------------
void GetSurveyDate(char strSurveyData[])
{
	//Declaring Variables
	char strHolder[50] = "";


	do
	{
		printf("Please enter the date the survey was taken in 'mm-dd-xxxx' format: \n");
		printf("(For example, January 1st, 2025 would be 01-01-2025): \n");

		scanf("%s", strHolder);
	} while (strHolder[2] != '-' && strHolder[5] != '-');

	//Adding strHolder to strSurveyData
	AppendStrSurveyData(strHolder, strSurveyData);
	//Adding Comma Seperator
	AppendStrSurveyData(",", strSurveyData);

	//Clearing strHolder for future use
	ClearString(strHolder);
}



// --------------------------------------------------------------------------------
// Name: GetState
// Abstract: Gets the state of the household
// --------------------------------------------------------------------------------
int GetState(char strSurveyData[])
{
	//Declaring Variables
	int intStateHolder = 0;

	do
	{
		printf("Please enter the number of the State you live in: \n");
		printf("(1 = Ohio, 2 = Kentucky): \n");

		scanf("%d", &intStateHolder);
	} while (intStateHolder != 1 && intStateHolder != 2);

	//Adding strState to strSurveyData
	if (intStateHolder == 1)
	{
		AppendStrSurveyData("Ohio", strSurveyData);
	}
	else
	{
		AppendStrSurveyData("Kentucky", strSurveyData);
	}

	//Adding Comma Seperator
	AppendStrSurveyData(",", strSurveyData);

	return intStateHolder;
}



// --------------------------------------------------------------------------------
// Name: GetCounty
// Abstract: Gets the County of the household
// --------------------------------------------------------------------------------
void GetCounty(int intState, char strSurveyData[])
{

	if (intState == 1)
	{
		GetOhioCounty(strSurveyData);
	}
	else
	{
		GetKentuckyCounty(strSurveyData);
	}

	//Adding Comma Seperator
	AppendStrSurveyData(",", strSurveyData);
}



// --------------------------------------------------------------------------------
// Name: GetOhioCounty
// Abstract: Gets the County if the State is Ohio
// --------------------------------------------------------------------------------
void GetOhioCounty(char strSurveyData[])
{
	//Declaring Variables
	int intCounty = 0;

	do
	{
		printf("Please enter the number of the County you live in: \n");
		printf("(1 = Hamilton, 2 = Butler): \n");

		scanf("%d", &intCounty);
	} while (intCounty != 1 && intCounty != 2);

	if (intCounty == 1)
	{
		AppendStrSurveyData("Hamilton", strSurveyData);
	}
	else
	{
		AppendStrSurveyData("Butler", strSurveyData);
	}
}



// --------------------------------------------------------------------------------
// Name: GetKentuckyCounty
// Abstract: Gets the County if the State is Ohio
// --------------------------------------------------------------------------------
void GetKentuckyCounty(char strSurveyData[])
{
	//Declaring Variables
	int intCounty = 0;
	do
	{
		printf("Please enter the number of the County you live in: \n");
		printf("(1 = Boone, 2 = Kenton): \n");

		scanf("%d", &intCounty);
	} while (intCounty != 1 && intCounty != 2);

	if (intCounty == 1)
	{
		AppendStrSurveyData("Boone", strSurveyData);
	}
	else
	{
		AppendStrSurveyData("Kenton", strSurveyData);
	}
}



// --------------------------------------------------------------------------------
// Name: GetRace
// Abstract: Gets the Race of the head of household
// --------------------------------------------------------------------------------
void GetRace(char strSurveyData[])
{
	//Declaring Variables
	int intRace = 0;

	do
	{
		printf("Please enter the number of the Race you identify as: \n");
		printf("(1 = Caucasian, 2 = African American, 3 = Hispanic, 4 = Asian, 5 = Other): \n");

		scanf("%d", &intRace);
	} while (intRace > 5 || intRace < 0);

	switch (intRace)
	{
	case 1:
		AppendStrSurveyData("Caucasian", strSurveyData);
		break;
	case 2:
		AppendStrSurveyData("African American", strSurveyData);
		break;
	case 3:
		AppendStrSurveyData("Hispanic", strSurveyData);
		break;
	case 4:
		AppendStrSurveyData("Asian", strSurveyData);
		break;
	case 5:
		AppendStrSurveyData("Other", strSurveyData);
		break;
	}

	//Adding Comma Seperator
	AppendStrSurveyData(",", strSurveyData);
}



// --------------------------------------------------------------------------------
// Name: GetNumberInHousehold
// Abstract: Gets the number of people living in the household
// --------------------------------------------------------------------------------
void GetNumberInHousehold(char strSurveyData[])
{
	//Declaring Variables
	int intNumberOfPeople = 0;
	char strHolder[50] = "";

	InitializeArray(strHolder, 50);

	do
	{
		printf("Please enter the number of people living in the household: \n");
		scanf("%d", &intNumberOfPeople);
	} while (intNumberOfPeople <= 0);

	sprintf(strHolder, "%d", intNumberOfPeople);

	AppendStrSurveyData(strHolder, strSurveyData);
	AppendStrSurveyData(",", strSurveyData);

	ClearString(strHolder);
}



// --------------------------------------------------------------------------------
// Name: GetYearlyincome
// Abstract: Gets the number of people living in the household
// --------------------------------------------------------------------------------
void GetYearlyIncome(char strSurveyData[])
{
	//Declaring Variables
	float sngYearlyIncome = 0;
	char strHolder[50] = "";

	InitializeArray(strHolder, 50);

	do
	{
		printf("Please enter the yearly income of the household (no commas): \n");
		scanf("%f", &sngYearlyIncome);
	} while (sngYearlyIncome <= 0);

	sprintf(strHolder, "%0.2f", sngYearlyIncome);

	AppendStrSurveyData(strHolder, strSurveyData);
	AppendStrSurveyData("\n", strSurveyData);

	ClearString(strHolder);
}



// --------------------------------------------------------------------------------
// Name: AskForMoreData
// Abstract: Asks if there is more data to be entered
// --------------------------------------------------------------------------------
int AskForMoreData()
{
	//Declaring Variables
	int intAgain = 0;

	do
	{
		printf("----------------------------------------------------------------------------- \n");
		printf("Is there more survey data to be entered? \n");
		printf("(1 = Yes, 0 = No) \n");
		printf("----------------------------------------------------------------------------- \n");
		scanf("%d", &intAgain);
	} while (intAgain != 1 && intAgain != 0);

	return intAgain;
}



// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------
// Mode 2: Display Data
// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------



// --------------------------------------------------------------------------------
// Name: DisplayData
// Abstract: Loads in Data and displays statistics based on user input
// --------------------------------------------------------------------------------
void DisplayData()
{
	//Declaring Variables
	int intNextAction = 0;
	int intArraySize = 0;
	udtSurveyType* paudtSurveyDataList = 0;
	intArraySize = FindSizeOfFile();
	paudtSurveyDataList = (udtSurveyType*)malloc((sizeof(udtSurveyType)) * intArraySize);
	ProcessData(paudtSurveyDataList, intArraySize);
	do
	{
		intNextAction = AskForNextDisplay();

		switch (intNextAction)
		{
		case 1:
			GetTotalSurveys(paudtSurveyDataList, intArraySize);
			break;
		case 2:
			GetTotalSurveysByCounty(paudtSurveyDataList, intArraySize);
			break;
		case 3:
			GetTotalSurveysByRace(paudtSurveyDataList, intArraySize);
			break;
		case 4:
			GetAverageIncome(paudtSurveyDataList, intArraySize);
			break;
		case 5:
			GetAverageIncomeByCounty(paudtSurveyDataList, intArraySize);
			break;
		case 6:
			GetAverageIncomeByRace(paudtSurveyDataList, intArraySize);
			break;
		case 7:
			GetPovertyRate(paudtSurveyDataList, intArraySize);
			break;
		case 8:
			GetPovertyRateByCounty(paudtSurveyDataList, intArraySize);
			break;
		case 9:
			GetPovertyRateByRace(paudtSurveyDataList, intArraySize);
		}

	} while (intNextAction != 0);

	free(paudtSurveyDataList);
}



// --------------------------------------------------------------------------------
// Name: AskForNextDisplay
// Abstract:Displays menu options to look at data and gets back user input
// --------------------------------------------------------------------------------
int AskForNextDisplay()
{
	// Declaring Variables
	int intNextAction = 0;

	do
	{
		printf("----------------------------------------------------------------------------- \n");
		printf("What would you like to see next? \n");
		printf("1 - Total Households Surveyed \n");
		printf("2 - Total Households Surveyed per County \n");
		printf("3 - Total Households Surveyed per Race \n");
		printf("4 - Average Household Income \n");
		printf("5 - Average Household Income by County \n");
		printf("6 - Average Household Income by Race \n");
		printf("7 - Poverty Rate \n");
		printf("8 - Poverty Rate by County \n");
		printf("9 - Poverty Rate by Race \n");
		printf("0 - Go Back to Main Menu \n");
		printf("(Type in the number next to your wanted selection) \n");
		printf("----------------------------------------------------------------------------- \n");
		scanf("%d", &intNextAction);
	} while (intNextAction < 0 && intNextAction > 9);

	return intNextAction;
}



// --------------------------------------------------------------------------------
// Name: GetTotalSurveys
// Abstract: Gets the total number of surveys taken
// --------------------------------------------------------------------------------
void GetTotalSurveys(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	//Declaring Variables
	int intTotal = 0;
	int intIndex = 0;

	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{
		intTotal = CheckForContent(paudtSurveyDataList + intIndex, intTotal);
	}

	printf("\n");
	printf("Total number of surveys taken: %d \n", intTotal);
	printf("\n");
}



// --------------------------------------------------------------------------------
// Name: GetTotalSurveysByCounty
// Abstract: Gets the total number of surveys taken by county
// --------------------------------------------------------------------------------
void GetTotalSurveysByCounty(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	//Declaring Variables
	int intOhioTotal = 0;
	int intKentuckyTotal = 0;
	int intHamiltonTotal = 0;
	int intButlerTotal = 0;
	int intBooneTotal = 0;
	int intKentonTotal = 0;
	int intIndex = 0;
	int intState = 0;
	int intCounty = 0;

	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{

		intState = ReadState((paudtSurveyDataList + intIndex)->strState);
		switch (intState)
		{
		case 1:
			intOhioTotal = CheckForContent((paudtSurveyDataList + intIndex), intOhioTotal);
			switch (intCounty)
			{
				intCounty = ReadOhioCounty((paudtSurveyDataList + intIndex)->strCounty);
				break;
			case 1:
				intHamiltonTotal = CheckForContent((paudtSurveyDataList + intIndex), intHamiltonTotal);
				break;
			case 2:
				intButlerTotal = CheckForContent((paudtSurveyDataList + intIndex), intButlerTotal);
				break;
			}
			break;
		case 2:
			intKentuckyTotal = CheckForContent((paudtSurveyDataList + intIndex), intKentuckyTotal);
			intCounty = ReadKentuckyCounty((paudtSurveyDataList + intIndex)->strCounty);
			switch (intCounty)
			{
			case 1:
				intBooneTotal = CheckForContent((paudtSurveyDataList + intIndex), intBooneTotal);
				break;
			case 2:
				intKentonTotal = CheckForContent((paudtSurveyDataList + intIndex), intKentonTotal);
				break;
			}
			break;
		}
	}

	printf("\n");
	printf("Ohio Surveys:     %d \n", intOhioTotal);
	printf("	Hamlton Surveys: %d \n", intHamiltonTotal);
	printf("	 Butler Surveys: %d \n", intButlerTotal);
	printf("Kentucky Surveys: %d \n", intKentuckyTotal);
	printf("	  Boone Surveys: %d \n", intBooneTotal);
	printf("	 Kenton Surveys: %d \n", intKentonTotal);
	printf("\n");
}



// --------------------------------------------------------------------------------
// Name: GetTotalSurveysByRace
// Abstract: Gets the total number of surveys taken by race
// --------------------------------------------------------------------------------
void GetTotalSurveysByRace(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	//Declaring Variables
	int intIndex = 0;
	int intRace = 0;
	int intCaucasianTotal = 0;
	int intAfricanAmericanTotal = 0;
	int intHispanicTotal = 0;
	int intAsianTotal = 0;
	int intOtherTotal = 0;

	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{
		intRace = ReadRace((paudtSurveyDataList + intIndex)->strRace);

		switch (intRace)
		{
		case 1:
			intCaucasianTotal = CheckForContent((paudtSurveyDataList + intIndex), intCaucasianTotal);
			break;
		case 2:
			intAfricanAmericanTotal = CheckForContent((paudtSurveyDataList + intIndex), intAfricanAmericanTotal);
			break;
		case 3:
			intHispanicTotal = CheckForContent((paudtSurveyDataList + intIndex), intHispanicTotal);
			break;
		case 4:
			intAsianTotal = CheckForContent((paudtSurveyDataList + intIndex), intAsianTotal);
			break;
		case 5:
			intOtherTotal = CheckForContent((paudtSurveyDataList + intIndex), intOtherTotal);
			break;
		}
	}

	printf("\n");
	printf("Total number of surveys taken by:  \n");
	printf("Caucasions:        %d \n", intCaucasianTotal);
	printf("African Americans: %d \n", intAfricanAmericanTotal);
	printf("Hispanic:          %d \n", intHispanicTotal);
	printf("Asians:            %d \n", intAsianTotal);
	printf("Other:             %d \n", intOtherTotal);
	printf("\n");
}



// --------------------------------------------------------------------------------
// Name: GetAverageIncome
// Abstract: Gets the average income of all surveys
// --------------------------------------------------------------------------------
void GetAverageIncome(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	//Declaring Variables
	int intIndex = 0;
	int intTotalSurveys = 0;
	float sngTotalIncome = 0;
	float sngAverageIncome = 0;


	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{
		intTotalSurveys = CheckForContent((paudtSurveyDataList + intIndex), intTotalSurveys);
		sngTotalIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
	}

	sngAverageIncome = sngTotalIncome / intTotalSurveys;

	printf("\n");
	printf("Average Income: $%0.2f", sngAverageIncome);
	printf("\n");
}



// --------------------------------------------------------------------------------
// Name: GetAverageIncomeByCounty
// Abstract: Gets the average income by county
// --------------------------------------------------------------------------------
void GetAverageIncomeByCounty(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	//Declaring Variables
	int intOhioTotal = 0;
	float sngOhioIncome = 0;
	float sngOhioAverageIncome = 0;
	int intKentuckyTotal = 0;
	float sngKentuckyIncome = 0;
	float sngKentuckyAverageIncome = 0;
	int intHamiltonTotal = 0;
	float sngHamiltonIncome = 0;
	float sngHamiltonAverageIncome = 0;
	int intButlerTotal = 0;
	float sngButlerIncome = 0;
	float sngButlerAverageIncome = 0;
	int intBooneTotal = 0;
	float sngBooneIncome = 0;
	float sngBooneAverageIncome = 0;
	int intKentonTotal = 0;
	float sngKentonIncome = 0;
	float sngKentonAverageIncome = 0;
	int intIndex = 0;
	int intState = 0;
	int intCounty = 0;

	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{
		intState = ReadState((paudtSurveyDataList + intIndex)->strState);
		switch (intState)
		{
		case 1:
			intCounty = ReadOhioCounty((paudtSurveyDataList + intIndex)->strCounty);
			intOhioTotal = CheckForContent((paudtSurveyDataList + intIndex), intOhioTotal);
			sngOhioIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
			switch (intCounty)
			{

			case 1:
				intHamiltonTotal = CheckForContent((paudtSurveyDataList + intIndex), intHamiltonTotal);
				sngHamiltonIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
				intState = 0;
				intCounty = 0;
				break;
			case 2:
				intButlerTotal = CheckForContent((paudtSurveyDataList + intIndex), intButlerTotal);
				sngButlerIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
				intState = 0;
				intCounty = 0;
				break;
			}
			break;
		case 2:
			intKentuckyTotal = CheckForContent((paudtSurveyDataList + intIndex), intKentuckyTotal);
			intCounty = ReadKentuckyCounty((paudtSurveyDataList + intIndex)->strCounty);
			sngKentuckyIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
			switch (intCounty)
			{
			case 1:
				intBooneTotal = CheckForContent((paudtSurveyDataList + intIndex), intBooneTotal);
				sngBooneIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
				intState = 0;
				intCounty = 0;
				break;
			case 2:
				intKentonTotal = CheckForContent((paudtSurveyDataList + intIndex), intKentonTotal);
				sngKentonIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
				intState = 0;
				intCounty = 0;
				break;
			}
		}
	}

	sngOhioAverageIncome = sngOhioIncome / intOhioTotal;
	sngKentuckyAverageIncome = sngKentuckyIncome / intKentuckyTotal;
	sngHamiltonAverageIncome = sngHamiltonIncome / intHamiltonTotal;
	sngButlerAverageIncome = sngButlerIncome / intButlerTotal;
	sngBooneAverageIncome = sngBooneIncome / intBooneTotal;
	sngKentonAverageIncome = sngKentonIncome / intKentonTotal;

	printf("\n");
	printf("Average Income of: \n");
	printf("Ohio:     $%0.2f \n", sngOhioAverageIncome);
	printf("	Hamlton: $%0.2f \n", sngHamiltonAverageIncome);
	printf("	 Butler: $%0.2f \n", sngButlerAverageIncome);
	printf("Kentucky: $%0.2f \n", sngKentuckyAverageIncome);
	printf("	  Boone: $%0.2f \n", sngBooneAverageIncome);
	printf("	 Kenton: $%0.2f \n", sngKentonAverageIncome);
	printf("\n");
}



// --------------------------------------------------------------------------------
// Name: GetAverageIncomeByRace
// Abstract: Gets the average income of surveys taken by race
// --------------------------------------------------------------------------------
void GetAverageIncomeByRace(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	//Declaring Variables
	int intIndex = 0;
	int intRace = 0;
	int intCaucasianTotal = 0;
	float sngCaucasianIncome = 0;
	float sngAverageCaucasianIncome = 0;
	int intAfricanAmericanTotal = 0;
	float sngAfricanAmericanIncome = 0;
	float sngAverageAfricanAmericanIncome = 0;
	int intHispanicTotal = 0;
	float sngHispanicIncome = 0;
	float sngAverageHispanicIncome = 0;
	int intAsianTotal = 0;
	float sngAsianIncome = 0;
	float sngAverageAsianIncome = 0;
	int intOtherTotal = 0;
	float sngOtherIncome = 0;
	float sngAverageOtherIncome = 0;

	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{
		intRace = ReadRace((paudtSurveyDataList + intIndex)->strRace);

		switch (intRace)
		{
		case 1:
			intCaucasianTotal = CheckForContent((paudtSurveyDataList + intIndex), intCaucasianTotal);
			sngCaucasianIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
			break;
		case 2:
			intAfricanAmericanTotal = CheckForContent((paudtSurveyDataList + intIndex), intAfricanAmericanTotal);
			sngAfricanAmericanIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
			break;
		case 3:
			intHispanicTotal = CheckForContent((paudtSurveyDataList + intIndex), intHispanicTotal);
			sngHispanicIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
			break;
		case 4:
			intAsianTotal = CheckForContent((paudtSurveyDataList + intIndex), intAsianTotal);
			sngAsianIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
			break;
		case 5:
			intOtherTotal = CheckForContent((paudtSurveyDataList + intIndex), intOtherTotal);
			sngOtherIncome += (paudtSurveyDataList + intIndex)->sngYearlyIncome;
			break;
		}
	}

	sngAverageCaucasianIncome = sngCaucasianIncome / intCaucasianTotal;
	sngAverageAfricanAmericanIncome = sngAfricanAmericanIncome / intAfricanAmericanTotal;
	sngAverageHispanicIncome = sngHispanicIncome / intHispanicTotal;
	sngAverageAsianIncome = sngAsianIncome / intAsianTotal;
	sngAverageOtherIncome = sngOtherIncome / intOtherTotal;

	printf("\n");
	printf("Total number of surveys taken by: \n");
	printf("Caucasions:	   $%0.2f \n", sngAverageCaucasianIncome);
	printf("African Americans: $%0.2f \n", sngAverageAfricanAmericanIncome);
	printf("Hispanic:	   $%0.2f \n", sngAverageHispanicIncome);
	printf("Asians:		   $%0.2f \n", sngAverageAsianIncome);
	printf("Other:		   $%0.2f \n", sngAverageOtherIncome);
	printf("\n");
}



// --------------------------------------------------------------------------------
// Name: GetPovertyRate
// Abstract: Gets the poverty rate of all surveys
// --------------------------------------------------------------------------------
void GetPovertyRate(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	//Declaring Variables - TotalPoverty and TotalSurveys are float to do math for sngPovertyRate
	int intIndex = 0;
	float sngTotalPoverty = 0;
	float* psngTotalPoverty = &sngTotalPoverty;
	float sngTotalSurveys = 0;
	float* psngTotalSurveys = &sngTotalSurveys;
	float sngPovertyRate;

	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{
		FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalSurveys, psngTotalPoverty);
	}
	sngPovertyRate = (sngTotalPoverty / sngTotalSurveys) * 100;

	printf("\n");
	printf("Poverty Rate: %0.2f%%", sngPovertyRate);
	printf("\n");
}



// --------------------------------------------------------------------------------
// Name: GetPovertyRatebyCounty
// Abstract: Gets the poverty rate of surveys taken by county
// --------------------------------------------------------------------------------
void GetPovertyRateByCounty(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	//Declaring Variables - TotalPoverty and TotalSurveys are float to do math for sngPovertyRate
	int intIndex = 0;
	float sngTotalOhioPoverty = 0;
	float* psngTotalOhioPoverty = &sngTotalOhioPoverty;
	float sngTotalOhioSurveys = 0;
	float* psngTotalOhioSurveys = &sngTotalOhioSurveys;
	float sngTotalHamiltonPoverty = 0;
	float* psngTotalHamiltonPoverty = &sngTotalHamiltonPoverty;
	float sngTotalHamiltonSurveys = 0;
	float* psngTotalHamiltonSurveys = &sngTotalHamiltonSurveys;
	float sngTotalButlerPoverty = 0;
	float* psngTotalButlerPoverty = &sngTotalButlerPoverty;
	float sngTotalButlerSurveys = 0;
	float* psngTotalButlerSurveys = &sngTotalButlerSurveys;
	float sngTotalKentuckyPoverty = 0;
	float* psngTotalKentuckyPoverty = &sngTotalKentuckyPoverty;
	float sngTotalKentuckySurveys = 0;
	float* psngTotalKentuckySurveys = &sngTotalKentuckySurveys;
	float sngTotalBoonePoverty = 0;
	float* psngTotalBoonePoverty = &sngTotalBoonePoverty;
	float sngTotalBooneSurveys = 0;
	float* psngTotalBooneSurveys = &sngTotalBooneSurveys;
	float sngTotalKentonPoverty = 0;
	float* psngTotalKentonPoverty = &sngTotalKentonPoverty;
	float sngTotalKentonSurveys = 0;
	float* psngTotalKentonSurveys = &sngTotalKentonSurveys;
	int intState = 0;
	int intCounty = 0;
	float sngOhioPovertyRate = 0;
	float sngHamiltonPovertyRate = 0;
	float sngButlerPovertyRate = 0;
	float sngKentuckyPovertyRate = 0;
	float sngBoonePovertyRate = 0;
	float sngKentonPovertyRate = 0;

	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{
		intState = ReadState((paudtSurveyDataList + intIndex)->strState);
		switch (intState)
		{
		case 1:
			intCounty = ReadOhioCounty((paudtSurveyDataList + intIndex)->strCounty);
			FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalOhioSurveys, psngTotalOhioPoverty);

			switch (intCounty)
			{

			case 1:
				FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalHamiltonSurveys, psngTotalHamiltonPoverty);
				intState = 0;
				intCounty = 0;
				break;
			case 2:
				FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalButlerSurveys, psngTotalButlerPoverty);
				intState = 0;
				intCounty = 0;
				break;
			}
			break;
		case 2:
			intCounty = ReadKentuckyCounty((paudtSurveyDataList + intIndex)->strCounty);
			FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalKentuckySurveys, psngTotalKentuckyPoverty);
			switch (intCounty)
			{
			case 1:
				FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalBooneSurveys, psngTotalBoonePoverty);
				intState = 0;
				intCounty = 0;
				break;
			case 2:
				FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalKentonSurveys, psngTotalKentonPoverty);
				intState = 0;
				intCounty = 0;
				break;
			}
		}
	}
	sngOhioPovertyRate = (sngTotalOhioPoverty / sngTotalOhioSurveys) * 100;
	sngHamiltonPovertyRate = (sngTotalHamiltonPoverty / sngTotalHamiltonSurveys) * 100;
	sngButlerPovertyRate = (sngTotalButlerPoverty / sngTotalButlerSurveys) * 100;
	sngKentuckyPovertyRate = (sngTotalKentuckyPoverty / sngTotalKentuckySurveys) * 100;
	sngBoonePovertyRate = (sngTotalBoonePoverty / sngTotalBooneSurveys) * 100;
	sngKentonPovertyRate = (sngTotalKentonPoverty / sngTotalKentonSurveys) * 100;

	printf("\n");
	printf("Poverty Rate of: \n");
	printf("Ohio:     %0.2f%% \n", sngOhioPovertyRate);
	printf("	Hamlton: %0.2f%% \n", sngHamiltonPovertyRate);
	printf("	 Butler: %0.2f%% \n", sngButlerPovertyRate);
	printf("Kentucky: %0.2f%% \n", sngKentuckyPovertyRate);
	printf("	  Boone: %0.2f%% \n", sngBoonePovertyRate);
	printf("	 Kenton: %0.2f%% \n", sngKentonPovertyRate);
	printf("\n");
}



// --------------------------------------------------------------------------------
// Name: GetPovertyRatebyRace
// Abstract: Gets the poverty rate of surveys taken by race
// --------------------------------------------------------------------------------
void GetPovertyRateByRace(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	//Declaring Variables - TotalPoverty and TotalSurveys are float to do math for sngPovertyRate
	int intIndex = 0;
	int intRace = 0;
	float sngTotalCaucasianPoverty = 0;
	float* psngTotalCaucasianPoverty = &sngTotalCaucasianPoverty;
	float sngTotalCaucasianSurveys = 0;
	float* psngTotalCaucasianSurveys = &sngTotalCaucasianSurveys;
	float sngTotalAfricanAmericanPoverty = 0;
	float* psngTotalAfricanAmericanPoverty = &sngTotalAfricanAmericanPoverty;
	float sngTotalAfricanAmericanSurveys = 0;
	float* psngTotalAfricanAmericanSurveys = &sngTotalAfricanAmericanSurveys;
	float sngTotalHispanicPoverty = 0;
	float* psngTotalHispanicPoverty = &sngTotalHispanicPoverty;
	float sngTotalHispanicSurveys = 0;
	float* psngTotalHispanicSurveys = &sngTotalHispanicSurveys;
	float sngTotalAsianPoverty = 0;
	float* psngTotalAsianPoverty = &sngTotalAsianPoverty;
	float sngTotalAsianSurveys = 0;
	float* psngTotalAsianSurveys = &sngTotalAsianSurveys;
	float sngTotalOtherPoverty = 0;
	float* psngTotalOtherPoverty = &sngTotalOtherPoverty;
	float sngTotalOtherSurveys = 0;
	float* psngTotalOtherSurveys = &sngTotalOtherSurveys;
	int intState = 0;
	int intCounty = 0;
	float sngCaucasianPovertyRate = 0;
	float sngAfricanAmericanPovertyRate = 0;
	float sngHispanicPovertyRate = 0;
	float sngAsianPovertyRate = 0;
	float sngOtherPovertyRate = 0;

	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{
		intRace = ReadRace((paudtSurveyDataList + intIndex)->strRace);

		switch (intRace)
		{
		case 1:
			sngTotalCaucasianSurveys = CheckForContent((paudtSurveyDataList + intIndex), sngTotalCaucasianSurveys);
			FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalCaucasianSurveys, psngTotalCaucasianPoverty);
			break;
		case 2:
			sngTotalAfricanAmericanSurveys = CheckForContent((paudtSurveyDataList + intIndex), sngTotalAfricanAmericanSurveys);
			FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalAfricanAmericanSurveys, psngTotalAfricanAmericanPoverty);
			break;
		case 3:
			sngTotalHispanicSurveys = CheckForContent((paudtSurveyDataList + intIndex), sngTotalHispanicSurveys);
			FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalHispanicSurveys, psngTotalHispanicPoverty);
			break;
		case 4:
			sngTotalAsianSurveys = CheckForContent((paudtSurveyDataList + intIndex), sngTotalAsianSurveys);
			FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalAsianSurveys, psngTotalAsianPoverty);
			break;
		case 5:
			sngTotalOtherSurveys = CheckForContent((paudtSurveyDataList + intIndex), sngTotalOtherSurveys);
			FindPovertyBracket(intIndex, (paudtSurveyDataList + intIndex), psngTotalOtherSurveys, psngTotalOtherPoverty);
			break;
		}
	}
	sngCaucasianPovertyRate = (sngTotalCaucasianPoverty / sngTotalCaucasianSurveys) * 100;
	sngAfricanAmericanPovertyRate = (sngTotalAfricanAmericanPoverty / sngTotalAfricanAmericanSurveys) * 100;
	sngHispanicPovertyRate = (sngTotalHispanicPoverty / sngTotalHispanicSurveys) * 100;
	sngAsianPovertyRate = (sngTotalAsianPoverty / sngTotalAsianSurveys) * 100;
	sngOtherPovertyRate = (sngTotalOtherPoverty / sngTotalOtherSurveys) * 100;

	printf("\n");
	printf("Total number of surveys taken by: \n");
	printf("Caucasions:	   %0.2f%% \n", sngCaucasianPovertyRate);
	printf("African Americans: %0.2f%% \n", sngAfricanAmericanPovertyRate);
	printf("Hispanic:	   %0.2f%% \n", sngHispanicPovertyRate);
	printf("Asians:		   %0.2f%% \n", sngAsianPovertyRate);
	printf("Other:		   %0.2f%% \n", sngOtherPovertyRate);
	printf("\n");
}



// --------------------------------------------------------------------------------
// Name: FindPovertyBracket
// Abstract: Finds variables needed for CheckPovertyRate and passes them along
// --------------------------------------------------------------------------------
void FindPovertyBracket(int intIndex, udtSurveyType* paudtSurveyDataList, 
						float* psngTotalSurveys, float* psngTotalPoverty)
{
	//Declaring Variables
	int intFlag = 0;
	short shtHousehold = 0;
	float sngYearlyIncome = 0;

	if (CheckForContent((paudtSurveyDataList), intFlag) == 1)
	{
		shtHousehold = (paudtSurveyDataList)->shtNumberInHouse;
		sngYearlyIncome = (paudtSurveyDataList)->sngYearlyIncome;
		*psngTotalSurveys += 1;

		if (shtHousehold >= 5)
		{
			*psngTotalPoverty += CheckPovertyRate(sngYearlyIncome, 40000);
		}
		else if (shtHousehold == 4)
		{
			*psngTotalPoverty += CheckPovertyRate(sngYearlyIncome, 30000);
		}
		else if (shtHousehold == 3)
		{
			*psngTotalPoverty += CheckPovertyRate(sngYearlyIncome, 25000);
		}
		else if (shtHousehold == 2)
		{
			*psngTotalPoverty += CheckPovertyRate(sngYearlyIncome, 18000);
		}
		else
		{
			*psngTotalPoverty += CheckPovertyRate(sngYearlyIncome, 12000);
		}
	}
	intFlag = 0;
}



// --------------------------------------------------------------------------------
// Name: CheckPovertyRate
// Abstract: Increases intTotal if poverty parameters are met
// --------------------------------------------------------------------------------
float CheckPovertyRate(float sngYearlyIncome, float sngPovertyThreshold)
{
	if (sngYearlyIncome < sngPovertyThreshold)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}



// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------
// File Subroutines and Functions
// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------



// --------------------------------------------------------------------------------
// Name: OpenInputFileForReading
// Abstract: Open the file for reading.  Return true if successful.
// --------------------------------------------------------------------------------
int OpenInputFileForReading(char strFileName[], FILE** ppfilInput)
{

	int intResultFlag = 0;

	// Open the file for reading
	*ppfilInput = fopen(strFileName, "rb");

	// Success?
	if (*ppfilInput != 0)
	{
		// Yes
		intResultFlag = 1;
	}
	else
	{
		// No
		printf("Error opening %s for reading!!!\n", strFileName);
	}

	return intResultFlag;
}



// --------------------------------------------------------------------------------
// Name: OpenInputFileForAppending
// Abstract: Open the file for appedning.  Return true if successful.
// --------------------------------------------------------------------------------
int OpenInputFileForAppending(char strFileName[], FILE** ppfilInput)
{

	int intResultFlag = 0;

	// Open the file for reading
	*ppfilInput = fopen(strFileName, "a");

	// Success?
	if (*ppfilInput != 0)
	{
		// Yes
		intResultFlag = 1;
	}
	else
	{
		// No
		printf("Error opening %s for modifying!!!\n", strFileName);
	}

	return intResultFlag;
}



// --------------------------------------------------------------------------------
// Name: FindSizeOfFile
// Abstract:Gets data SurveyData.txt and stores it in audtSurveyDataList
// --------------------------------------------------------------------------------
int FindSizeOfFile()
{
	//Declaring Variables and Pointers
	FILE* pfilInput = 0;
	int intResultFlag = 0;
	char chrLetter = 0;
	int intTotal = 0;

	// Try to open the file for reading (notice you have to double up the backslashes)
	intResultFlag = OpenInputFileForReading("SurveyData.txt", &pfilInput);

	// Was the file opened?
	if (intResultFlag == 1)
	{

		// Yes, read in records until end of file( EOF )
		while (feof(pfilInput) == 0)
		{
			// Read one character
			chrLetter = fgetc(pfilInput);

			if (chrLetter == 10) //Using ASCII value of new line, 10, for comparison
			{
				intTotal += 1;
			}
		}
		// Clean up
		fclose(pfilInput);

		return intTotal;
	}
}



// --------------------------------------------------------------------------------
// Name: ProcessData
// Abstract:Gets data SurveyData.txt and stores it in paudtSurveyDataList
// --------------------------------------------------------------------------------
void ProcessData(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	//Declaring Variables and Pointers
	FILE* pfilInput = 0;
	int intResultFlag = 0;
	char strBuffer[100] = "";
	char chrLetter = 0;
	int intIndex = 0;

	// Try to open the file for reading (notice you have to double up the backslashes)
	intResultFlag = OpenInputFileForReading("SurveyData.txt", &pfilInput);

	// Was the file opened?
	if (intResultFlag == 1)
	{

		// Yes, read in records until end of file( EOF )
		while (feof(pfilInput) == 0)
		{
			// Read one character
			chrLetter = fgetc(pfilInput);

			//Puts character into string for later use if it isn't a new line character
			AppendStringWithCharacter(strBuffer, chrLetter);


			if (chrLetter == 10) //Using ASCII value of new line, 10, for comparison
			{
				InsertData(intIndex, strBuffer, paudtSurveyDataList);
				ClearString(strBuffer);
				intIndex += 1;
			}
		}
		// Clean up
		fclose(pfilInput);
	}
}



// --------------------------------------------------------------------------------
// Name: InsertData
// Abstract: Breaks down strBuffer and stores each piece into paudtSurveyDataList
// --------------------------------------------------------------------------------
void InsertData(int intIndex, char strBuffer[], udtSurveyType* paudtSurveyDataList)
{
	//Declaring Variables
	int intLengthofBuffer = 0;
	int intPlaceHolderIndex = 0;
	char strPlaceHolder[100] = "";
	int intCommaCount = 0;
	int* pintCommaCount = &intCommaCount;

	//Finding length of strBuffer
	intLengthofBuffer = FindLengthOfString(strBuffer);

	for (intPlaceHolderIndex = 0; intPlaceHolderIndex < intLengthofBuffer; intPlaceHolderIndex += 1)
	{
		if (strBuffer[intPlaceHolderIndex] != 44 && strBuffer[intPlaceHolderIndex] != '\n' && strBuffer[intPlaceHolderIndex] != '\r') // Using ASCII value of comma, 44, for comparison
		{
			AppendStringWithCharacter(strPlaceHolder, strBuffer[intPlaceHolderIndex]);
		}
		else
		{
			BreakDownSurveyData(pintCommaCount, *&paudtSurveyDataList + intIndex, strPlaceHolder);
			ClearString(strPlaceHolder);
		}
	}
	intCommaCount = 0;
}



// --------------------------------------------------------------------------------
// Name: BreakDownSurveyData
// Abstract: Breaks down and stores each piece of data into paudtSurveyDataList
// --------------------------------------------------------------------------------
void BreakDownSurveyData(int* pintCommaCount, udtSurveyType* ppudtSurveyData, char strPlaceHolder[])
{
	switch (*pintCommaCount)
	{
	case 0:
		CopyString(ppudtSurveyData->strDate, strPlaceHolder);
		break;
	case 1:
		CopyString(ppudtSurveyData->strState, strPlaceHolder);
		break;
	case 2:
		CopyString(ppudtSurveyData->strCounty, strPlaceHolder);
		break;
	case 3:
		CopyString(ppudtSurveyData->strRace, strPlaceHolder);
		break;
	case 4:
		ppudtSurveyData->shtNumberInHouse = ConvertStringToShort(strPlaceHolder);
		break;
	case 5:
		ppudtSurveyData->sngYearlyIncome = strtof(strPlaceHolder, NULL);
		break;
	}
	*pintCommaCount += 1;
}



// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------
// Array Subroutines and Functions
// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------



// --------------------------------------------------------------------------------
// Name: InitializeArray
// Abstract: Sets all values in array to zero
// --------------------------------------------------------------------------------
void InitializeArray(char strSource[], int intArraySize)
{
	//Declaring Variables
	int intIndex = 0;

	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{
		strSource[intIndex] = 0;
	}
}



// --------------------------------------------------------------------------------
// Name: InitializeSurveyList
// Abstract: Initializes all Surveys in the list
// --------------------------------------------------------------------------------
void InitializeSurveyList(udtSurveyType* paudtSurveyDataList, int intArraySize)
{
	int intIndex = 0;

	if (intArraySize == 0)
	{
		InitializeSurvey(*(&paudtSurveyDataList + intIndex));
	}

	for (intIndex = 0; intIndex < intArraySize; intIndex += 1)
	{
		//Pass a single array element by pointer
		InitializeSurvey(*(&paudtSurveyDataList + intIndex));
	}
}



// --------------------------------------------------------------------------------
// Name: InitializeSurvey
// Abstract: Initializes an individual survey
// --------------------------------------------------------------------------------
void InitializeSurvey(udtSurveyType* ppudtSurveyData)
{
	CopyString(ppudtSurveyData->strDate, "");
	CopyString(ppudtSurveyData->strState, "");
	CopyString(ppudtSurveyData->strCounty, "");
	CopyString(ppudtSurveyData->strRace, "");
	ppudtSurveyData->shtNumberInHouse = 0;
	ppudtSurveyData->sngYearlyIncome = 0;
}



// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------
// String Subroutines and Functions
// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------



// --------------------------------------------------------------------------------
// Name: AppendStrSurveyData
// Abstract: Combines input data into a single string seperated by commas
// --------------------------------------------------------------------------------
void AppendStrSurveyData(char strSource[], char strDestination[])
{
	//Declaring Variables
	int intStartPoint = 0;
	int intStopPoint = 0;

	//Finding the new starting point to add the data
	intStartPoint = FindLengthOfString(strDestination);
	intStopPoint = FindLengthOfString(strSource);

	//Appending intNewElement to paintValues
	CopyStringArray(strSource, strDestination, intStartPoint, intStopPoint);
}



// --------------------------------------------------------------------------------
// Name: CopyString
// Abstract: Populates strDestination with contents of strSource
// --------------------------------------------------------------------------------
void CopyString(char strDestination[], char strSource[])
{
	//Declaring Variables
	int intIndex = 0;

	//Populating strDestination
	while (strSource[intIndex] != 0)
	{
		strDestination[intIndex] = strSource[intIndex];
		intIndex += 1;
	}

	//Adding null to terminate strDestination
	strDestination[intIndex] = 0;

}



// --------------------------------------------------------------------------------
// Name: CopyStringArray
// Abstract: Populates strDestination with contents of strSource with input start
//			 and stop points
// --------------------------------------------------------------------------------
void CopyStringArray(char strSource[], char strDestination[], int intStartPoint, int intStopPoint)
{
	//Declaring Variables
	int intIndex = 0;

	//Populating strDestination
	for (intIndex = 0; intIndex < intStopPoint; intIndex += 1)
	{
		if (strSource[intIndex] != 0)
		{
			strDestination[intIndex + intStartPoint] = strSource[intIndex];
		}
	}
}



// --------------------------------------------------------------------------------
// Name: ClearString
// Abstract: Resets passed in string
// --------------------------------------------------------------------------------
void ClearString(char strSource[])
{
	//Declaring Variables
	int intIndex = 0;
	int intStringLength = FindLengthOfString(strSource);

	while (intIndex <= intStringLength)
	{
		strSource[intIndex] = 0;
		intIndex += 1;
	}
}



// --------------------------------------------------------------------------------
// Name: AppendStringWithCharacter
// Abstract: Appends contents of strSource to strDestination
// --------------------------------------------------------------------------------
void AppendStringWithCharacter(char strDestination[], char strSource)
{
	//Declaring Variables
	int intIndex = 0;
	//Gets length of strDestinationLength
	int intStrDestinationLength = FindLengthOfString(strDestination);

	//Populating strDestination
	strDestination[intStrDestinationLength] = strSource;
	intIndex += 1;

	//Adding null to terminate strDestination
	strDestination[intStrDestinationLength + 1] = 0;

}



// --------------------------------------------------------------------------------
// Name: CheckForContent
// Abstract: Counts Survey if strDate is not null, then increments intTotal if not null
// --------------------------------------------------------------------------------
int CheckForContent(udtSurveyType* pudtSurveyData, int intTotal)
{
	if (pudtSurveyData->strDate[0] != NULL)
	{
		return intTotal += 1;
	}
	else
	{
		return intTotal;
	}
}



// --------------------------------------------------------------------------------
// Name: ConvertStringToShort
// Abstract: Converts input string of numbers into a short value
// --------------------------------------------------------------------------------
short ConvertStringToShort(char strSource[])
{
	//Declaring Variables
	short shtConvertedNumber = 0;
	int intIndex = 0;
	int intStrSourceLength = 0;

	intStrSourceLength = FindLengthOfString(strSource);

	for (intIndex = 0; intIndex <= intStrSourceLength; intIndex += 1)
	{
		if (strSource[intIndex] >= 48 && strSource[intIndex] <= 57)
		{
			shtConvertedNumber = (shtConvertedNumber * 10) + (strSource[intIndex] - 48);
		}
	}

	return shtConvertedNumber;
}



// --------------------------------------------------------------------------------
// Name: FindLengthOfString
// Abstract: Finds the length of a string
// --------------------------------------------------------------------------------
int FindLengthOfString(char strSource[])
{
	//Declaring Variables
	int intIndex = 0;

	//Counting each character in the string
	while (strSource[intIndex] != 0)
	{
		intIndex += 1;
	}

	return intIndex;
}



// --------------------------------------------------------------------------------
// Name: ReadState
// Abstract:Checks the State variable, and returns an integer based on the content
// --------------------------------------------------------------------------------
int ReadState(char strState[])
{
	// 1 = Ohio, 2 = Kentucky
	if (strState[0] == 'O')
	{
		return 1;
	}
	else
	{
		return 2;
	}
}



// --------------------------------------------------------------------------------
// Name: ReadOhioCounty
// Abstract:Checks the County variable, and returns an integer based on the content
// --------------------------------------------------------------------------------
int ReadOhioCounty(char strCounty[])
{
	// 1 = Hamilton, 2 = Butler
	if (strCounty[0] == 'H')
	{
		return 1;
	}
	else
	{
		return 2;
	}
}



// --------------------------------------------------------------------------------
// Name: ReadKentuckyCounty
// Abstract:Checks the County variable, and returns an integer based on the content
// --------------------------------------------------------------------------------
int ReadKentuckyCounty(char strCounty[])
{
	// 1 = Boone, 2 = Kenton
	if (strCounty[0] == 'B')
	{
		return 1;
	}
	else
	{
		return 2;
	}
}



// --------------------------------------------------------------------------------
// Name: ReadRace
// Abstract:Checks the Race variable, and returns an integer based on the content
// --------------------------------------------------------------------------------
int ReadRace(char strRace[])
{
	// 1 = Caucasian, 2 = African American, 3 = Hispanic, 4 = Asian, 5 = Other
	if (strRace[0] == 'C')
	{
		return 1;
	}
	else if (strRace[0] == 'A' && strRace[1] == 'f')
	{
		return 2;
	}
	else if (strRace[0] == 'H')
	{
		return 3;
	}
	else if (strRace[0] == 'A' && strRace[1] == 's')
	{
		return 4;
	}
	else
	{
		return 5;
	}
}